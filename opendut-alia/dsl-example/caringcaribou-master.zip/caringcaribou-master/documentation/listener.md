# Listener
````
$ cc.py listener -h

-------------------
CARING CARIBOU v0.x
-------------------

Loaded module 'listener'

usage: cc.py listener [-h] [-r]

Passive listener module for CaringCaribou

optional arguments:
 -h, --help     show this help message and exit
 -r, --reverse  Reversed sorting of results
 ```
