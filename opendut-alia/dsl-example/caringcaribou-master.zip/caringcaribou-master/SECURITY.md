# Security Policy



## Reporting a Vulnerability

Vulnerabilities can be reported through GitHub Security Advisory, available at <https://github.com/CaringCaribou/caringcaribou/security/advisories/new>
